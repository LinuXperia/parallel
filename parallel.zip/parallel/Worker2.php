<?php
	use parallel\{Channel, Sync, Events, Events\Event};

	print('LOADING Worker 2'.PHP_EOL);

	$Worker1 = function() use($GlobalSyncBarrier) {
		print('Worker 2 Started'.PHP_EOL);
		
		$bRunWorker = true;
		
		$i = 0;
		
		do {
			echo 'Worker 2 Count: '.$i++.PHP_EOL;
			
			$GlobalSyncBarrier->wait();
			
			if( $GlobalSyncBarrier->get() == 'break')
				$bRunWorker = false;
		}
		while($bRunWorker);
		
		print('EXIT Worker 2'.PHP_EOL);
	};
?>
