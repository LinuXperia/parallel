<?php
	use parallel\{Runtime, Channel, Sync};

	$MainRuntime = new Runtime();

	$GlobalSyncBarrier = new Sync();

	include 'Worker1.php';
	$Worker1 = $MainRuntime->run( $Worker1 );

	include 'Worker2.php';
	$Worker2 = $MainRuntime->run( $Worker2 );

	do {
		print('PRESS RETURN TO LOOP WORKERS AND ESC + RETURN TO EXIT WORKERS'.PHP_EOL);
		
		$InputKey = ord(fgetc(STDIN));
		
		if($InputKey == 27) {
			$GlobalSyncBarrier->set('break');
			$GlobalSyncBarrier->notify(true);
		}
		else {
			$GlobalSyncBarrier->set('continue');
			$GlobalSyncBarrier->notify(true);
		}
	}
	while($InputKey != 27);

	$MainChannel->close();
?>
